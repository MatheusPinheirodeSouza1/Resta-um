#ifndef RESTAUM_H
#define RESTAUM_H

#include <Peca.h>
#include <QMainWindow>

namespace Ui {
    class RestaUm;
}

class RestaUm : public QMainWindow {
    Q_OBJECT

public:
    explicit RestaUm(QWidget *parent = 0);
    ~RestaUm();

signals:
    void gameOver1();
    void gameOver2();

private:
    Ui::RestaUm *ui;
    Peca* m_pecas[7][7];    
    QAction* aux;
    int rowselec;
    int colselec;
    bool selecao=false;

private slots:
    void Verificafim();
    void Acao(int r,int c,int op);
    bool Verifica(int r,int c,int op);
    void Mais();
    void Flecha();
    void Banquinho();
    void Piramide();
    void Losangulo();
    void Esvazia();
    void Tradicional();
    void Cruz();
    void Novo();
    void play();
    void mostrarSobre();
    void mostrarFimJogo1();
    void mostrarFimJogo2();
    void trocarModo(QAction* modo);

};

#endif // RESTAUM_H
