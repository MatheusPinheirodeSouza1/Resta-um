#ifndef RESTAUM_H
#define RESTAUM_H

#include <Peca.h>
#include <QMainWindow>

namespace Ui {
    class RestaUm;
}

class RestaUm : public QMainWindow {
    Q_OBJECT

public:
    explicit RestaUm(QWidget *parent = 0);
    ~RestaUm();

signals:
    void gameOver1();
    void gameOver2();

private:
    Ui::RestaUm *ui;
    Peca* m_pecas[7][7];    
    QAction* aux;//uma auxiliar que guarda o modo atual
    int rowselec;//armazena a linha da peça selecionada
    int colselec;//armazena a coluna da peça selecionada
    bool selecao=false;//auxiliar para selecionar um jumpable
    int PecaRestantes=0;//auxiliar para numero de peças restantes

private slots:
    void Verificafim();//verifica se ainda existe possibilidades de jogadas
    void Acao(int r,int c,int op);//faz a parte logica do jogo que seria "comer"
    bool Verifica(int r,int c,int op);//verifica se é possivel "comer"
    void Mais();
    void Flecha();
    void Banquinho();
    void Piramide();
    void Losangulo();
    void Esvazia();
    void Tradicional();
    void Cruz();
    void Novo();
    void play();
    void mostrarSobre();
    void mostrarFimJogo1();//exibe mensagem indicando que o jogador ganhou
    void mostrarFimJogo2();//exive mensagem indicando que não há mais possibilidades de jogada
    void trocarModo(QAction* modo);
    void update(int PecaRestantes);//da um refresh no numero de peças restantes
};

#endif // RESTAUM_H
