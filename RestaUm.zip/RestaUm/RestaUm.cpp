#include "RestaUm.h"
#include "ui_RestaUm.h"

#include <QDebug>
#include <QActionGroup>
#include <QMessageBox>

RestaUm::RestaUm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RestaUm) {

    ui->setupUi(this);

    QActionGroup* group = new QActionGroup(this);
    group->setExclusive(true);
    group->addAction(ui->actionTradicional);
    group->addAction(ui->actionCruz);
    group->addAction(ui->actionMais);
    group->addAction(ui->actionBanquinho);
    group->addAction(ui->actionFlecha);
    group->addAction(ui->actionPiramide);
    group->addAction(ui->actionLosango);


        for (int r = 0; r < 7; r++) {
            for (int c = 0; c < 7; c++) {
                m_pecas[r][c] =
                  this->findChild<Peca*>(
                    QString("peca%1%2").arg(r).arg(c));
                if (m_pecas[r][c]) {
                    m_pecas[r][c]->setRow(r);//atribui linha no setRow da peça em questão
                    m_pecas[r][c]->setCol(c);//atribui Coluna no setCol da peça em questão
                    QObject::connect(
                      m_pecas[r][c],
                      SIGNAL(clicked()),
                      this,
                      SLOT(play()));

                      m_pecas[r][c]->setState(Peca::Filled);
                }
            }
        }
        m_pecas[3][3]->setState(Peca::Empty);

    aux=ui->actionTradicional;
    QObject::connect(
        group,
        SIGNAL(triggered(QAction*)),
        this,
        SLOT(trocarModo(QAction*)));

    QObject::connect(
        ui->actionSair,
        SIGNAL(triggered()),
        qApp,
        SLOT(quit()));

    QObject::connect(
        ui->actionNovo,
        SIGNAL(triggered()),
        this,
        SLOT(Novo()));

    QObject::connect(
        ui->actionSobre,
        SIGNAL(triggered()),
        this,
        SLOT(mostrarSobre()));

    QObject::connect(
        this,
        SIGNAL(gameOver1()),
        this,
        SLOT(mostrarFimJogo1()));

    QObject::connect(
        this,
        SIGNAL(gameOver2()),
        this,
        SLOT(mostrarFimJogo2()));

    this->adjustSize();
    this->setFixedSize(this->size());
}
void RestaUm::Novo(){
    selecao=false;
    trocarModo(aux);
}

void RestaUm::Tradicional() {
    for (int r = 0; r < 7; r++) {
        for (int c = 0; c < 7; c++) {
           Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
    }
    m_pecas[3][3]->setState(Peca::Empty);
}


void RestaUm::Cruz() {
    for (int r = 1; r < 5; r++) {
        for (int c = 3; c < 4; c++) {
           Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
    }
    m_pecas[2][2]->setState(Peca::Filled);
    m_pecas[2][4]->setState(Peca::Filled);
}



void RestaUm::Mais() {

    for (int r = 1; r < 6; r++) {
        for (int c = 3; c < 4; c++) {
           Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
    }
    for (int c = 1; c < 6; c++) {
    m_pecas[3][c]->setState(Peca::Filled);
    }
}


void RestaUm::Banquinho() {
    for (int r = 0; r < 4; r++) {
        for (int c = 2; c < 5; c++) {
            Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
    }
    m_pecas[3][3]->setState(Peca::Empty);
}

void RestaUm::Flecha() {
    int x=3,y=4;
    for (int r = 0; r < 3; r++) {
        for (int c = x; c < y; c++) {
            Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
        x--;
        y++;
    }
    m_pecas[3][3]->setState(Peca::Filled);
    m_pecas[4][3]->setState(Peca::Filled);
    for (int r = 5; r < 7; r++) {
        for (int c = 2; c < 5; c++) {
            Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
    }
}


void RestaUm::Piramide() {
    int x=3,y=4;
    for (int r = 1; r < 5; r++) {
        for (int c = x; c < y; c++) {
            Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);

            }
        }
        x--;
        y++;
    }
}

void RestaUm::Losangulo() {
    int x=3,y=4;
    for (int r = 0; r < 7; r++) {
        for (int c = x; c < y; c++) {
            Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Filled);
            }
        }
        if(r>=3){
            x++;
            y--;
        }else{
            x--;
            y++;
        }
    }
     m_pecas[3][3]->setState(Peca::Empty);
}

void RestaUm::Esvazia() {//Limpa o jogo para poder alterar modo
    for (int r = 0; r < 7; r++) {
        for (int c = 0; c < 7; c++) {
           Peca* peca = m_pecas[r][c];
            if (peca) {
                m_pecas[r][c]->setState(Peca::Empty);
            }
        }
    }
}

RestaUm::~RestaUm() {
    delete ui;
}

bool RestaUm::Verifica(int r,int c,int op){//verifica se é possivel faze a jogada
    switch (op) {//op defini sentido
    case 1://baixo
        if(r+2>=7){
            return false;
        }
        else if((r==3 || r==4)&&(c==0 || c==1 || c==5 || c==6)){
            return false;
        }else{
            return true;
        }

        break;
    case 2://cima
        if(r-2<0){

            return false;
        }
        else if((r==3 || r==2)&&(c==0 || c==1 || c==5 || c==6)){
            return false;
        }else{
            return true;
        }

        break;
    case 3://direita
        if(c+2>=7){
            return false;
        }
        else if((r==0 || r==1 || r==5 || r==6)&&( c==3 || c==4 )){
            return false;
        }else{
            return true;
        }

        break;
    case 4://esquerda
        if(c-2<0){
            return false;
        }
        else if((r==0 || r==1 || r==5 || r==6)&&( c==3 || c==2 )){
            return false;
        }else{
            return true;
        }

        break;
    default:
        return false;
        break;
    }
}

void RestaUm::Acao(int r,int c,int op){//faz a jogada
    int i=2;
    switch (op) {//op defini a que direção a jogada vai ser feita
    case 1://baixo
        m_pecas[r+i][c]->setState(Peca::Filled);
        m_pecas[rowselec][colselec]->setState(Peca::Empty);
        i--;
        m_pecas[r+i][c]->setState(Peca::Empty);
        break;
    case 2://cima
        m_pecas[r-i][c]->setState(Peca::Filled);
        m_pecas[rowselec][colselec]->setState(Peca::Empty);
        i--;
        m_pecas[r-i][c]->setState(Peca::Empty);

        break;
    case 3://direita
        m_pecas[r][c+i]->setState(Peca::Filled);
        m_pecas[rowselec][colselec]->setState(Peca::Empty);
        i--;
        m_pecas[r][c+i]->setState(Peca::Empty);

        break;
    case 4://esquerda
        m_pecas[r][c-i]->setState(Peca::Filled);
        m_pecas[rowselec][colselec]->setState(Peca::Empty);
        i--;
        m_pecas[r][c-i]->setState(Peca::Empty);
        break;
    default:
        break;
    }
    for (i = 0; i < 7; i++) {//apos a escolha todos os outros estados de jumpable são modificados para empty
        for (int j = 0; j < 7; j++) {
           Peca* peca = m_pecas[i][j];
            if (peca) {
                if(m_pecas[i][j]->getState()==Peca::Jumpable){
                    m_pecas[i][j]->setState(Peca::Empty);
                }
            }
        }
    }

}

void RestaUm::Verificafim(){// verifica o fim do jogo
    int cont=0;
    for (int i = 0; i < 7; i++) {//verifica caso so haja uma peça
        for (int j = 0; j < 7; j++) {
           Peca* peca = m_pecas[i][j];
            if (peca) {
                if(m_pecas[i][j]->getState()==Peca::Filled){
                    cont++;
                }
            }
        }
    }
    if(cont==1){//se tiver apenas uma peça emiti sinal de vitoria
        emit gameOver1();
    }else{//caso ainda reste mais peças verifica se existe jogas possiveis
        cont=0;//
        for (int i = 0; i < 5; i++) {//verifica na coluna
            for (int j = 0; j < 5; j++) {
                Peca* peca1 = m_pecas[i][j];
                Peca* peca2 = m_pecas[i][j+1];
                Peca* peca3 = m_pecas[i][j+2];
                if (peca1 && peca2 && peca3) {
                    if(((peca1->getState()==Peca::Filled  ||peca1->getState()==Peca::Selected) && peca2->getState()==Peca::Filled && (peca3->getState()==Peca::Empty||peca3->getState()==Peca::Jumpable) ) ||
                            ((peca1->getState()==Peca::Empty||peca1->getState()==Peca::Jumpable) && peca2->getState()==Peca::Filled && (peca3->getState()==Peca::Filled  ||peca3->getState()==Peca::Selected))){
                        cont++;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {//verfica na linha
            for (int j = 0; j < 5; j++) {
                Peca* peca1 = m_pecas[j][i];
                Peca* peca2 = m_pecas[j+1][i];
                 Peca* peca3 = m_pecas[j+2][i];
                if (peca1 && peca2 && peca3) {
                    if(((peca1->getState()==Peca::Filled  ||peca1->getState()==Peca::Selected) && peca2->getState()==Peca::Filled && (peca3->getState()==Peca::Empty||peca3->getState()==Peca::Jumpable)) ||
                            ((peca1->getState()==Peca::Empty||peca1->getState()==Peca::Jumpable)&& peca2->getState()==Peca::Filled && (peca3->getState()==Peca::Filled  ||peca3->getState()==Peca::Selected))){
                        cont++;
                    }
                }
            }

        }
        if(cont==0){
             emit gameOver2();
        }
    }
}

void RestaUm::play() {
    Peca* peca = qobject_cast<Peca*>(
                QObject::sender());
    int r=peca->getRow();
    int c=peca->getCol();
        int op=0;
        int i=1;
        int contador=0;
        if(m_pecas[r][c]->getState()==Peca::Filled && selecao==false){
            rowselec=r;
            colselec=c;
         if(Verifica(r,c,1) && m_pecas[r+i][c]->getState()==Peca::Filled){
              i++;     
              if(m_pecas[r+i][c]->getState()==Peca::Empty){
                contador=contador+1;
                op=1;
                m_pecas[r+i][c]->setState(Peca::Jumpable);
              }
          }
         i=1;

         if(Verifica(r,c,2) && m_pecas[r-i][c]->getState()==Peca::Filled ){
              i++;
              if(m_pecas[r-i][c]->getState()==Peca::Empty){
                  contador=contador+1;
                  op=2;
                   m_pecas[r-i][c]->setState(Peca::Jumpable);
              }
          }
         i=1;

         if(Verifica(r,c,3) && m_pecas[r][c+i]->getState()==Peca::Filled ){
              i++;
              if(m_pecas[r][c+i]->getState()==Peca::Empty){
                  contador=contador+1;
                  op=3;
                   m_pecas[r][c+i]->setState(Peca::Jumpable);
              }
          }

         i=1;

         if(Verifica(r,c,4) && m_pecas[r][c-i]->getState()==Peca::Filled ){
              i++;
              if(m_pecas[r][c-i]->getState()==Peca::Empty){
                contador=contador+1;
                op=4;
                 m_pecas[r][c-i]->setState(Peca::Jumpable);
              }
          }
         if(contador==1){
             Acao(r,c,op);
         }else if(contador!=0){
             m_pecas[r][c]->setState(Peca::Selected);
             selecao=true;
         }
         Verificafim();
        }if(m_pecas[r][c]->getState()==Peca::Jumpable){
                if(r>rowselec){
                     Acao(rowselec,colselec,1);
                     selecao=false;
                }else if(r<rowselec){
                     Acao(rowselec,colselec,2);
                     selecao=false;
                }else if(c>colselec){
                    Acao(rowselec,colselec,3);
                    selecao=false;
                }else if(c<colselec){
                    Acao(rowselec,colselec,4);
                    selecao=false;
                }
                Verificafim();
        }
}

void RestaUm::mostrarSobre() {
    QMessageBox::information(this,
       tr("Sobre"),
       tr("Resta Um\n\nMatheu Pinheiro - matheusps12@hotmail.com"));
}

void RestaUm::mostrarFimJogo1() {
    QMessageBox::information(this,
       tr("Fim"),
       tr("Parabéns, você venceu!"));
}

void RestaUm::mostrarFimJogo2() {
    QMessageBox::information(this,
       tr("Fim"),
       tr("Não exitem mais jogas possíveis!"));
}

void RestaUm::trocarModo(QAction* modo) {
    aux = modo;
    if (modo == ui->actionTradicional){
        Esvazia();
        Tradicional();
        qDebug() << "modo: tradicional";
    }
    else if (modo == ui->actionCruz){
        Esvazia();
        Cruz();
        qDebug() << "modo: cruz";
    }
    else if (modo == ui->actionMais){
        Esvazia();
        Mais();
        qDebug() << "modo: mais";
    }
    else if (modo == ui->actionBanquinho){
        Esvazia();
        Banquinho();
        qDebug() << "modo: banquinho";
    }
    else if (modo == ui->actionFlecha){
        Esvazia();
        Flecha();
        qDebug() << "modo: flecha";
    }
    else if (modo == ui->actionPiramide){
        Esvazia();
        Piramide();
        qDebug() << "modo: piramide";
    }
    else if (modo == ui->actionLosango){
        Esvazia();
        Losangulo();
        qDebug() << "modo: losango";
    }
}
